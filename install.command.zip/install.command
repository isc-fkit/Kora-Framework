#!/usr/bin/env bash
# install.command — Cài Kora-Framework skills vào ~/.claude (managed, KHÔNG để lại folder source).
#
# Cách dùng:
#   - Double-click file này (macOS), hoặc
#   - 1 dòng:  bash <(curl -fsSL https://raw.githubusercontent.com/isc-fkit/Kora-Framework/release/install.command)
#   - Chạy lại bất cứ lúc nào = CẬP NHẬT (tự kéo bản mới, thêm skill mới).
#
# Test cục bộ (không tải mạng):  KORA_SRC=/duong/dan/repo  bash install.command
set -euo pipefail

REPO="${KORA_REPO:-isc-fkit/Kora-Framework}"
REF="${KORA_REF:-release}"
SRC_LOCAL="${KORA_SRC:-}"                 # set = copy từ repo cục bộ (để test), bỏ trống = tải GitHub
DEST_CMD="$HOME/.claude/commands"
DEST_CORE="$HOME/.claude/kora-framework"

have(){ command -v "$1" >/dev/null 2>&1; }
pause(){ [ -t 0 ] && read -r -p "${1:-Nhấn Enter để đóng...}" _ || true; }
die(){ echo ""; echo "❌ $1"; echo ""; pause; exit 1; }

# Tự gỡ nhãn quarantine cho thư mục chứa script (macOS) → double-click lần sau sạch.
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd || echo "")"
if [ "$(uname -s 2>/dev/null)" = "Darwin" ] && have xattr && [ -n "$SELF_DIR" ]; then
  xattr -dr com.apple.quarantine "$SELF_DIR" >/dev/null 2>&1 || true
fi

echo "================================================================"
echo "  Kora-Framework — cài skills vào ~/.claude"
echo "================================================================"
echo ""
mkdir -p "$DEST_CMD" "$DEST_CORE"

# --- Lấy cây nguồn CORE (SRC) ---
if [ -n "$SRC_LOCAL" ]; then
  SRC="$SRC_LOCAL"
  echo "ℹ️  Dùng nguồn cục bộ: $SRC"
else
  have curl || die "Thiếu 'curl'."
  have tar  || die "Thiếu 'tar'."
  TMP="$(mktemp -d "${TMPDIR:-/tmp}/kora-install.XXXXXX")"
  trap 'rm -rf "$TMP"' EXIT
  echo "⬇️  Đang tải bản mới nhất..."
  curl -fsSL "https://github.com/$REPO/archive/refs/heads/$REF.tar.gz" -o "$TMP/src.tgz" \
    || die "Tải thất bại. Kiểm tra mạng rồi thử lại."
  tar -xzf "$TMP/src.tgz" -C "$TMP" || die "Giải nén thất bại."
  SRC="$(find "$TMP" -maxdepth 1 -type d -name "*-$REF" | head -n1)"
  [ -n "$SRC" ] && [ -d "$SRC" ] || die "Không thấy thư mục nguồn sau giải nén."
fi

# --- 1) Skills → ~/.claude/commands/ (xóa kora-* cũ trước → bỏ skill đã đổi tên/gỡ) ---
echo "📥 Cài lệnh /kora-* ..."
rm -f "$DEST_CMD"/kora-*.md 2>/dev/null || true
cp "$SRC"/.claude/commands/kora-*.md "$DEST_CMD"/ 2>/dev/null || die "Không thấy skill kora-*.md trong nguồn."
# Skill CHỈ-DUY-TRÌ (maintainer-only) — KHÔNG cài cho người dùng thường (phát hành = chỉ người viết repo).
for ms in kora-release; do rm -f "$DEST_CMD/$ms.md" 2>/dev/null || true; done
N="$(ls -1 "$DEST_CMD"/kora-*.md 2>/dev/null | wc -l | tr -d ' ')"

# --- 2) CORE hỗ trợ → ~/.claude/kora-framework/ (ẩn, quản lý; KHÔNG phải folder source để sửa) ---
echo "📥 Cài workflows hỗ trợ ..."
for d in workflows scripts templates config tools; do
  if [ -e "$SRC/$d" ]; then
    rm -rf "$DEST_CORE/$d" 2>/dev/null || true
    cp -R "$SRC/$d" "$DEST_CORE/$d"
  fi
done
# Workflow CHỈ-DUY-TRÌ — gỡ khỏi bản cài người dùng (phát hành/tiến hóa hệ thống chỉ ở người viết repo).
for mw in 12-release.md 13-evolve-system.md; do rm -f "$DEST_CORE/workflows/$mw" 2>/dev/null || true; done
[ -f "$SRC/CLAUDE.md" ] && cp "$SRC/CLAUDE.md" "$DEST_CORE/" || true
# Domain + rule preset đã nằm trong config/ vừa copy (gồm Healthcare/Y tế). Đếm để báo.
NDOM="$(ls -1 "$DEST_CORE"/config/domain-presets/*.md 2>/dev/null | wc -l | tr -d ' ')"
[ -f "$DEST_CORE/config/domain-presets/healthcare.md" ] || echo "⚠️  Thiếu preset Healthcare — nguồn cài có thể cũ."

# --- Resolve thư mục Downloads động (theo OS; tự fallback nếu không có) ---
DL_BASE="$HOME/Downloads"
if [ "$(uname -s 2>/dev/null)" = "Linux" ] && have xdg-user-dir; then
  _d="$(xdg-user-dir DOWNLOAD 2>/dev/null || true)"
  [ -n "$_d" ] && DL_BASE="$_d"
fi
[ -d "$DL_BASE" ] || DL_BASE="$HOME"   # Downloads không tồn tại → về home

# --- 3) Dựng ROOT Knowledge-Base trong Downloads + KHỞI TẠO project NGAY (folder skill BÊN TRONG) ---
ROOT="${KORA_PROJECT:-$DL_BASE/Knowledge-Base}"
SKILL_DIR="$ROOT/Skill"
echo "📦 Khởi tạo project tại: $ROOT"
mkdir -p "$SKILL_DIR"

# Folder skill nằm BÊN TRONG ROOT (để upload tay vào Cowork) — refresh mỗi lần cài/update.
rm -f "$SKILL_DIR"/kora-*.md 2>/dev/null || true
cp "$DEST_CMD"/kora-*.md "$SKILL_DIR"/ 2>/dev/null || true

# Khởi tạo cấu trúc project GỌN ngay trong ROOT — CHỈ khi chưa phải project Kora (tránh đè tri thức).
if [ ! -f "$ROOT/config/factory-config.yaml" ] && [ ! -d "$ROOT/config/domain-presets" ]; then
  echo "📁 Dựng cấu trúc project (docs/ + vault + config) bên trong $ROOT"
  mkdir -p "$ROOT"/docs/01-domain "$ROOT"/docs/02-product "$ROOT"/docs/03-features "$ROOT"/docs/04-design \
           "$ROOT"/docs/05-architecture "$ROOT"/docs/06-decisions "$ROOT"/docs/07-research "$ROOT"/docs/08-glossary \
           "$ROOT/inbox" "$ROOT/.kb" "$ROOT/config" "$ROOT/Kora_Brain/00_Index"
  [ -f "$DEST_CORE/config/factory-config.example.yaml" ] && cp "$DEST_CORE/config/factory-config.example.yaml" "$ROOT/config/factory-config.yaml"
  [ -d "$DEST_CORE/config/domain-presets" ] && cp -R "$DEST_CORE/config/domain-presets" "$ROOT/config/domain-presets"
  printf '@~/.claude/kora-framework/CLAUDE.md\n' > "$ROOT/CLAUDE.md"   # Cowork/CLI nạp rule orchestrator khi mở folder
  printf '# Knowledge Base\n' > "$ROOT/Kora_Brain/00_Index/Knowledge-Base.md"
fi

# (Dọn folder Kora-Skills kiểu cũ nếu còn sót từ bản trước)
rm -rf "$DL_BASE/Kora-Skills" "$DL_BASE/Kora-Skills.zip" 2>/dev/null || true

echo ""
echo "✅ Đã cài $N skill Kora + $NDOM domain preset (gồm Healthcare/Y tế, Retail, Manufacturing…) vào ~/.claude."
echo "   📁 Project đã khởi tạo sẵn: $ROOT"
echo "   📁 Folder skill (upload vào Cowork): $SKILL_DIR"
echo "   • Claude Code (CLI): mở  $ROOT  → gõ  /kora-init  (đặt domain/tên) rồi  /kora-scan."
echo "   • Claude Cowork (App): upload các file kora-*.md trong  $SKILL_DIR/  vào mục Skills → mở  $ROOT  → gõ /kora-init."
echo "   Cập nhật: chạy lại file này → skill mới tự kéo vào ~/.claude VÀ $SKILL_DIR/ (tri thức GIỮ NGUYÊN)."
echo "   Gỡ:       chạy uninstall.command (hoặc /kora-uninstall)."
pause
